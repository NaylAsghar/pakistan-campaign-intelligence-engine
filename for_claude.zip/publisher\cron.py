"""Protected cron trigger endpoint for hosted environments (Render / Railway).

External schedulers (cron-job.org, GitHub Actions, Render Cron) send:
    POST /cron/run
    Authorization: Bearer <CRON_TOKEN>   (or header X-Cron-Token: <CRON_TOKEN>)

Runs due YouTube publish jobs and refreshes statistics for published videos.
"""

from __future__ import annotations

import secrets

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session

from publisher.config import get_settings
from publisher.db import get_db
from publisher.worker import run_due_jobs, sync_published_stats

router = APIRouter()


def _verify_cron_token(
    authorization: str = Header(""),
    x_cron_token: str = Header(""),
) -> None:
    expected = get_settings().CRON_TOKEN
    if not expected:
        raise HTTPException(status_code=503, detail="CRON_TOKEN is not configured.")

    provided = x_cron_token.strip()
    if not provided and authorization.lower().startswith("bearer "):
        provided = authorization[7:].strip()

    if not provided or not secrets.compare_digest(
        provided.encode("utf-8"), expected.encode("utf-8")
    ):
        raise HTTPException(status_code=401, detail="Invalid cron token.")


@router.post("/cron/run")
def cron_run(
    _: None = Depends(_verify_cron_token),
    db: Session = Depends(get_db),
) -> dict:
    publish_summary = run_due_jobs(db=db)
    stats_updated = sync_published_stats(db=db)
    return {
        "ok": True,
        "publish": publish_summary,
        "stats_snapshots_added": stats_updated,
    }
